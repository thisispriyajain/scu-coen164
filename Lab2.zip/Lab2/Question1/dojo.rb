module Dojo
	class Push
		def self. up
			30
		end
	end
end