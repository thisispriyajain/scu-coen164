require "./gym"

gym_push = Gym::Push.up
p gym_push #up returns 40

require "./dojo"
dojo_push = Dojo::Push.up
p dojo_push #up returns 30