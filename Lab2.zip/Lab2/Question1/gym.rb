module Gym
	class Push
		def self.up
			40
		end
	end
end