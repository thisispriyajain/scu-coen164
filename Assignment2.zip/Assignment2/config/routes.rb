Rails.application.routes.draw do
  get 'access/new'
  post 'access/create'
  get 'access/destroy'
  get 'admin/order_num'
  resources :users
  resources :orders
  resources :lineitems
  resources :carts
  get 'shopper/index'
  
  get '/', to: "shopper#index", as: 'shopper' #shopper_url
  #root "shopper#index", as: 'shopper' #shopper_url

  resources :products
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  get 'shopper', to: 'shopper#index'
  get 'admin', to: 'admin#order_num'
  get 'access', to: "access#new"

  # Defines the root path route ("/")
  # root "articles#index"
end
