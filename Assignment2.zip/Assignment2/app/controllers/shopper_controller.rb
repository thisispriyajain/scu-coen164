class ShopperController < ApplicationController
  include CurrentCart
  before_action :set_cart
  
  def index
     if params[:name].present?
      @products = Product.where("name LIKE ?", "%#{params[:name]}%").order(:name)
    elsif params[:description].present?
      @products = Product.where("description LIKE ?", "%#{params[:description]}%").order(:name)
    else
      @products = Product.order(:name)
    end
  end

  def show
    @product = Product.find(params[:id])
  end
end
