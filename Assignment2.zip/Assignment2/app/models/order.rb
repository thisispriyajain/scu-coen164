class Order < ApplicationRecord
	has_many(:lineitems, dependent: :destroy)

	validates(:name, :address, :email, presence: true)
	PAYMENT_TYPES = ["Check", "Credit Card", "Venmo", "PayPal"]
	validates(:paytype, inclusion: PAYMENT_TYPES)

	def update_lineitems_table(cart_obj)
		#self is the new @order object that represent the new row in Order table
		cart_obj.lineitems.each do |item|
			item.cart_id = nil
			item.order_id = self.id
			item.save
		end
	end
end
