Rails.application.routes.draw do
  get 'new_access/login'
  get 'new_access/authenticate'
  get 'new_access/logout'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  # Defines the root path route ("/")
  # root "articles#index"

  get '/access/login'
  get '/access/authenticate'
  get '/access/logout'
  get '/', to: 'root#main'

  resources :students

  root "access#login"

end

