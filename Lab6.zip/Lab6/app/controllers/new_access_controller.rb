class NewAccessController < ApplicationController
  def login
  end

  def authenticate
  end

  def logout
  end
end
